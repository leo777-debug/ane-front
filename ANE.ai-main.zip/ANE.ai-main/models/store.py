import uuid
from datetime import datetime, timezone
from typing import Any, Dict, List, Optional

class Store:
    def __init__(self):
        self._simulations: Dict[str, Dict[str, Any]] = {}

    def create_simulation(self, sim_id: str, request_data: Dict[str, Any]) -> str:
        self._simulations[sim_id] = {
            "id": sim_id,
            "status": "pending",
            "request": request_data,
            "results": [],
            "analytics": None,
            "error": None,
            "created_at": datetime.now(timezone.utc).isoformat(),
        }
        return sim_id

    def get_simulation(self, sim_id: str) -> Optional[Dict[str, Any]]:
        return self._simulations.get(sim_id)

    def update_simulation(self, sim_id: str, data: Dict[str, Any]) -> None:
        if sim_id in self._simulations:
            self._simulations[sim_id].update(data)

    def list_simulations(self) -> List[Dict[str, Any]]:
        return list(self._simulations.values())

store = Store()
