import logging
from typing import List, Dict, Any

logger = logging.getLogger(__name__)

class GraphRAG:
    """
    Implements Graph-based Retrieval-Augmented Generation.
    Connects entities and concepts to provide agents with deep contextual memory.
    Mirofish-style: Focuses on multi-hop relations and cultural nuances.
    """
    def __init__(self):
        # Richer graph with Mirofish-style cultural and behavioral nodes
        self.graph = {
            "gen z": {
                "values": ["authenticity", "social justice", "transparency"],
                "humor": ["absurdist", "self-deprecating", "ironic"],
                "platforms": ["tiktok", "instagram", "discord"],
                "triggers": ["cringe", "over-production", "fake news"]
            },
            "millennial": {
                "values": ["nostalgia", "work-life balance", "experiences"],
                "humor": ["sarcastic", "observational", "pop-culture"],
                "platforms": ["instagram", "facebook", "linkedin"],
                "triggers": ["burnout", "housing market", "avocado toast"]
            },
            "tiktok": {
                "vibe": ["fast-paced", "raw", "trend-driven"],
                "format": ["short-form", "vertical", "audio-first"],
                "audience": ["gen z", "alpha"],
                "logic": ["algorithmic discovery", "community challenges"]
            },
            "youtube": {
                "vibe": ["educational", "community", "long-form"],
                "format": ["horizontal", "storytelling", "high-production"],
                "audience": ["global", "all ages"],
                "logic": ["search-driven", "subscriber loyalty"]
            },
            "mena": {
                "culture": ["hospitality", "family-centric", "tradition-meets-modern"],
                "trends": ["gaming", "luxury", "entrepreneurship"],
                "platforms": ["snapchat", "instagram", "tiktok"],
                "nuance": ["high mobile penetration", "youth-heavy demographic"]
            },
            "global": {
                "trends": ["sustainability", "ai", "digital nomadism"],
                "values": ["connectivity", "diversity", "innovation"]
            }
        }

    def query(self, entities: List[str]) -> str:
        """
        Retrieves context from the graph for a given set of entities.
        Mirofish-style: Traverses relations to build a narrative context.
        """
        context_parts = []
        seen_entities = set()
        
        # Normalize entities to lowercase for matching
        normalized_entities = [e.lower().strip() for e in entities]
        
        for entity in normalized_entities:
            if entity in self.graph and entity not in seen_entities:
                seen_entities.add(entity)
                relations = self.graph[entity]
                
                # Build a descriptive paragraph for each entity
                desc = f"For {entity.upper()}: "
                rel_strings = []
                for rel, targets in relations.items():
                    rel_strings.append(f"their {rel} include {', '.join(targets)}")
                
                desc += "; ".join(rel_strings) + "."
                context_parts.append(desc)
                
                # Simple 1-hop expansion (Mirofish style)
                for targets in relations.values():
                    for target in targets:
                        if target in self.graph and target not in seen_entities and target not in normalized_entities:
                            # Add related entity context briefly
                            sub_rel = self.graph[target]
                            first_rel = list(sub_rel.keys())[0]
                            context_parts.append(f"Related {target.upper()} insight: {first_rel} are {', '.join(sub_rel[first_rel])}.")
                            seen_entities.add(target)
        
        if not context_parts:
            return "General audience insights: Focus on high engagement, clear value proposition, and platform-native formatting."
            
        return "\n\n".join(context_parts)

    def add_relation(self, source: str, relation: str, target: str):
        source = source.lower()
        if source not in self.graph:
            self.graph[source] = {}
        if relation not in self.graph[source]:
            self.graph[source][relation] = []
        if target not in self.graph[source][relation]:
            self.graph[source][relation].append(target)

graph_rag = GraphRAG()
