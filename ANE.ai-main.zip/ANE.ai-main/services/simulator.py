"""
ANE Simulator Service
Streams synthetic agent reactions to content using OpenRouter (free models).
Falls back to a simple rule-based generator if all LLM calls fail.
"""
import asyncio
import json
import random
import logging
from datetime import datetime, timezone
from typing import Any, AsyncGenerator, Dict, List

import httpx

from config import Config

logger = logging.getLogger("ane.simulator")

# ── Agent persona templates ────────────────────────────────────────────────

AGE_LABELS = {
    "gen_z": "Gen Z (18-26)",
    "millennial": "Millennial (27-42)",
    "gen_x": "Gen X (43-58)",
    "boomer": "Boomer (59+)",
}

PLATFORM_EMOJIS = {
    "YouTube": "▶️",
    "TikTok": "🎵",
    "Instagram": "📸",
    "Twitter/X": "🐦",
}

SENTIMENTS = ["positive", "neutral", "negative", "mixed"]

REACTION_TYPES = ["like", "share", "comment", "skip", "save", "report"]


class Simulator:
    def __init__(self):
        self.logger = logger

    def _build_agent_prompt(
        self,
        content: Dict[str, Any],
        demographics: Dict[str, Any],
        agent_index: int,
    ) -> str:
        age_groups = demographics.get("age_groups", ["millennial"])
        genders = demographics.get("genders", ["male", "female"])
        platforms = demographics.get("platforms", ["YouTube"])
        region = demographics.get("region", "global")

        age = random.choice(age_groups)
        gender = random.choice(genders)
        platform = random.choice(platforms)

        age_label = AGE_LABELS.get(age, age)
        content_title = content.get("title", "Untitled")
        content_text = content.get("text", "")[:500]
        content_type = content.get("type", "general")

        return f"""You are a {age_label} {gender} social media user from {region}, browsing {platform}.

You just encountered this {content_type} content:
Title: {content_title}
Content: {content_text}

Respond ONLY with a valid JSON object (no markdown, no explanation) with these exact keys:
{{
  "agent_id": "agent_{agent_index}",
  "age_group": "{age}",
  "gender": "{gender}",
  "platform": "{platform}",
  "region": "{region}",
  "sentiment": "<one of: positive, neutral, negative, mixed>",
  "reaction_type": "<one of: like, share, comment, skip, save, report>",
  "comment": "<a short authentic reaction in 1-2 sentences, in character>",
  "engagement_score": <integer 1-10>,
  "would_share": <true or false>
}}"""

    async def _call_openrouter(self, prompt: str, model: str) -> Dict[str, Any]:
        """Call OpenRouter API and return parsed JSON reaction."""
        headers = {
            "Authorization": f"Bearer {Config.OPENROUTER_API_KEY}",
            "Content-Type": "application/json",
            "HTTP-Referer": "https://ane-ai.onrender.com",
            "X-Title": "ANE Simulator",
        }
        payload = {
            "model": model,
            "messages": [{"role": "user", "content": prompt}],
            "max_tokens": 300,
            "temperature": 0.85,
        }
        async with httpx.AsyncClient(timeout=30) as client:
            resp = await client.post(
                f"{Config.OPENROUTER_BASE_URL}/chat/completions",
                headers=headers,
                json=payload,
            )
            resp.raise_for_status()
            data = resp.json()
            raw = data["choices"][0]["message"]["content"].strip()
            # Strip markdown code fences if present
            if raw.startswith("```"):
                raw = raw.split("```")[1]
                if raw.startswith("json"):
                    raw = raw[4:]
            return json.loads(raw)

    def _fallback_reaction(self, agent_index: int, content: Dict, demographics: Dict) -> Dict[str, Any]:
        """Rule-based fallback when all LLM calls fail."""
        age_groups = demographics.get("age_groups", ["millennial"])
        genders = demographics.get("genders", ["male", "female"])
        platforms = demographics.get("platforms", ["YouTube"])
        region = demographics.get("region", "global")

        age = random.choice(age_groups)
        gender = random.choice(genders)
        platform = random.choice(platforms)
        sentiment = random.choice(SENTIMENTS)
        reaction = random.choice(REACTION_TYPES)
        score = random.randint(1, 10)

        comments = {
            "positive": "This is really interesting content, I enjoyed it!",
            "neutral": "It's okay, nothing too special but not bad either.",
            "negative": "Not really my thing, I'd probably scroll past this.",
            "mixed": "Some parts were good, others not so much.",
        }

        return {
            "agent_id": f"agent_{agent_index}",
            "age_group": age,
            "gender": gender,
            "platform": platform,
            "region": region,
            "sentiment": sentiment,
            "reaction_type": reaction,
            "comment": comments[sentiment],
            "engagement_score": score,
            "would_share": score >= 7,
        }

    async def _simulate_agent(
        self,
        agent_index: int,
        content: Dict[str, Any],
        demographics: Dict[str, Any],
    ) -> Dict[str, Any]:
        """Try each OpenRouter model in order, fall back to rule-based if all fail."""
        if Config.OPENROUTER_API_KEY:
            prompt = self._build_agent_prompt(content, demographics, agent_index)
            for model in Config.OPENROUTER_MODELS:
                try:
                    reaction = await self._call_openrouter(prompt, model)
                    reaction["agent_id"] = f"agent_{agent_index}"
                    return reaction
                except Exception as e:
                    self.logger.warning(f"Model {model} failed for agent {agent_index}: {e}")
                    continue

        # All LLM calls failed or no API key — use fallback
        self.logger.info(f"Using fallback for agent {agent_index}")
        return self._fallback_reaction(agent_index, content, demographics)

    async def run_simulation_stream(
        self,
        content: Dict[str, Any],
        demographics: Dict[str, Any],
        agent_count: int,
    ) -> AsyncGenerator[Dict[str, Any], None]:
        """
        Async generator that yields reaction events one by one,
        then a final 'complete' event.
        """
        # Run agents with slight stagger to simulate real-time feel
        semaphore = asyncio.Semaphore(5)  # max 5 concurrent LLM calls

        async def bounded_simulate(idx: int) -> Dict[str, Any]:
            async with semaphore:
                await asyncio.sleep(random.uniform(0.1, 0.5))
                return await self._simulate_agent(idx, content, demographics)

        tasks = [bounded_simulate(i) for i in range(agent_count)]

        for coro in asyncio.as_completed(tasks):
            reaction = await coro
            yield {
                "type": "reaction",
                "timestamp": datetime.now(timezone.utc).isoformat(),
                **reaction,
            }

        yield {
            "type": "complete",
            "timestamp": datetime.now(timezone.utc).isoformat(),
            "total_agents": agent_count,
        }

    def compute_analytics(self, reactions: List[Dict[str, Any]]) -> Dict[str, Any]:
        """Compute aggregate analytics from a list of reaction events."""
        if not reactions:
            return {}

        total = len(reactions)

        # Sentiment breakdown
        sentiment_counts: Dict[str, int] = {}
        for r in reactions:
            s = r.get("sentiment", "neutral")
            sentiment_counts[s] = sentiment_counts.get(s, 0) + 1

        # Reaction type breakdown
        reaction_counts: Dict[str, int] = {}
        for r in reactions:
            rt = r.get("reaction_type", "skip")
            reaction_counts[rt] = reaction_counts.get(rt, 0) + 1

        # Engagement
        scores = [r.get("engagement_score", 5) for r in reactions]
        avg_score = round(sum(scores) / len(scores), 2) if scores else 0

        # Share rate
        share_count = sum(1 for r in reactions if r.get("would_share", False))
        share_rate = round(share_count / total * 100, 1)

        # Platform breakdown
        platform_counts: Dict[str, int] = {}
        for r in reactions:
            p = r.get("platform", "Unknown")
            platform_counts[p] = platform_counts.get(p, 0) + 1

        # Age group breakdown
        age_counts: Dict[str, int] = {}
        for r in reactions:
            a = r.get("age_group", "unknown")
            age_counts[a] = age_counts.get(a, 0) + 1

        # Viral score (0-100)
        positive_ratio = sentiment_counts.get("positive", 0) / total
        viral_score = round((avg_score / 10 * 0.5 + positive_ratio * 0.3 + share_rate / 100 * 0.2) * 100)

        return {
            "total_reactions": total,
            "avg_engagement_score": avg_score,
            "share_rate_percent": share_rate,
            "viral_score": viral_score,
            "sentiment_breakdown": sentiment_counts,
            "reaction_type_breakdown": reaction_counts,
            "platform_breakdown": platform_counts,
            "age_group_breakdown": age_counts,
            "top_comments": [
                r.get("comment", "") for r in reactions[:5] if r.get("comment")
            ],
        }

    async def simulate(self, content_text: str, agent_count_or_list: Any, context: str = "") -> List[Dict[str, Any]]:
        """
        Main entry point for simulations. 
        Supports both (text, count, context) and (text, agents) signatures.
        """
        if isinstance(agent_count_or_list, int):
            agent_count = agent_count_or_list
        else:
            # If it's a list (e.g. from asi_evolve), use its length
            agent_count = len(agent_count_or_list)

        # Build dummy content and demographics for the simulation
        # In a real scenario, we'd pass these through, but we'll use defaults for now
        content = {"title": "Simulation", "text": content_text, "type": "article"}
        demographics = {
            "age_groups": ["millennial", "gen_z"],
            "genders": ["male", "female"],
            "platforms": ["YouTube", "TikTok", "Instagram"],
            "region": "global"
        }

        reactions = []
        async for event in self.run_simulation_stream(content, demographics, agent_count):
            if event["type"] == "reaction":
                reactions.append(event)
        
        return reactions

# Export a single instance
simulator = Simulator()

